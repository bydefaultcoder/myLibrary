ckeditor-light-theme
====================
